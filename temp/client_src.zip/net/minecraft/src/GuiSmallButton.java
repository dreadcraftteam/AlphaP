package net.minecraft.src;

public class GuiSmallButton extends GuiButton {
	public GuiSmallButton(int i1, int i2, int i3, String string4) {
		super(i1, i2, i3, 150, 20, string4);
	}
}
