package com.jcraft.jorbis;

class Mapping0$LookMapping0 {
	InfoMode mode;
	Mapping0$InfoMapping0 map;
	Object[] time_look;
	Object[] floor_look;
	Object[] floor_state;
	Object[] residue_look;
	PsyLook[] psy_look;
	FuncTime[] time_func;
	FuncFloor[] floor_func;
	FuncResidue[] residue_func;
	int ch;
	float[][] decay;
	int lastframe;
	final Mapping0 this$0;

	Mapping0$LookMapping0(Mapping0 mapping01) {
		this.this$0 = mapping01;
	}
}
