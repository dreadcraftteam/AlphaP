package com.jcraft.jorbis;

class Residue0$LookResidue0 {
	Residue0$InfoResidue0 info;
	int map;
	int parts;
	int stages;
	CodeBook[] fullbooks;
	CodeBook phrasebook;
	int[][] partbooks;
	int partvals;
	int[][] decodemap;
	int postbits;
	int phrasebits;
	int frames;
	final Residue0 this$0;

	Residue0$LookResidue0(Residue0 residue01) {
		this.this$0 = residue01;
	}
}
