package paulscode.sound;

class SimpleThread$1 extends Thread {
	final SimpleThread this$0;

	SimpleThread$1(SimpleThread simpleThread1) {
		this.this$0 = simpleThread1;
	}

	public void run() {
		SimpleThread.access$000(this.this$0);
	}
}
