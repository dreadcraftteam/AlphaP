package paulscode.sound;

class MidiChannel$1 {
}
