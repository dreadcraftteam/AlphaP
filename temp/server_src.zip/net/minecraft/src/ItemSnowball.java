package net.minecraft.src;

public class ItemSnowball extends Item {
	public ItemSnowball(int i1) {
		super(i1);
		this.maxStackSize = 16;
	}
}
